package com.studquiz;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Login {
    static final String DB_URL = "jdbc:mysql://localhost/quiz";
    static final String USER = "root";
    static final String PASS = "Root@123";
    static final String QUERY = "SELECT id, Question, OptionA, OptionB, OptionC, OptionD,answer FROM qquestion"; // Ensure correct table and column names
    static int count=0;
    // Function to display a question and get user's answer
    public static void qquestion(String id, String question, String a, String b, String c, String d,String e) {
        String answer = JOptionPane.showInputDialog(id + ". " + question + "\n" + "A: " + a + "\n" + "B: " + b + "\n" + "C: " + c + "\n" + "D: " + d);
        //System.out.println(answer);
        //System.out.println(e);
        if (answer.toUpperCase().equals(e.toUpperCase())) {
        	count=count+1;
        }     
        // Here you can add logic to check if the answer is correct
    }
    // Function to authenticate user
    public static boolean authenticate(String username, String password) {
        String loginQuery = "SELECT EmailID,password FROM registration WHERE EmailID ='"+ username+"' AND password ='"+password+"'";
        //String loginQuery = "SELECT username,password FROM users WHERE username ='"+ username+"' AND password ='"+password+"'";
        System.out.println(loginQuery);
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(loginQuery)) {
           // pstmt.setString(1, username);
           // pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            boolean isAuthenticated = rs.next();
            System.out.println(isAuthenticated);
            System.out.println(rs.getString(1));
            System.out.println(rs.getString(2));
            rs.close();
            return isAuthenticated;  // Return true if a record is found
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public static void insertuserresult(String username) {
    	 String insertQuery = "INSERT INTO QResults (username, score) VALUES (?, ?)";
         try {
         	Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery);
             pstmt.setString(1, username);
             pstmt.setInt(2, count);
             int rowsAffected = pstmt.executeUpdate();
        
             if (rowsAffected > 0) {
                 JOptionPane.showMessageDialog(null, "User result Inserted successful!");
             } else {
                 JOptionPane.showMessageDialog(null, "User result Inserted  failed!");
             }
         }catch (SQLException e) {
             e.printStackTrace();
             JOptionPane.showMessageDialog(null, "Registration failed: " + e.getMessage());
         }
    }
    // Function to show the quiz
    public static void showQuiz() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(QUERY);
            while (rs.next()) {
                qquestion(String.valueOf(rs.getInt("id")), rs.getString("Question"), rs.getString("OptionA"),
                		rs.getString("OptionB"), rs.getString("OptionC"), 
                		rs.getString("OptionD"),rs.getString("answer"));
                break;
            }
            
            rs.close();
            System.out.println("Total number of Questios answered:"+count);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        JTextField usernameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        //showRegistrationForm();

    
        String[] options = {"OK", "Registration", "Cancel"};
        int option = JOptionPane.showOptionDialog(null, panel, "Login", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (option == 0) {  // OK button pressed
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            System.out.println("Username: " + username);  // Debugging info
            System.out.println("Password: " + password);  // Debugging info

            if (authenticate(username, password)) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                showQuiz();  // Show the quiz if login is successful
                String display="User Name:"+username + "\n Score" + count;
                JOptionPane.showMessageDialog(null, display);
                insertuserresult(username);

            } else {
                JOptionPane.showMessageDialog(null, "Login failed! Please check your credentials.");
            }
        } else if (option == 1) {  // Registration button pressed
            Registration.showRegistrationForm();  // Show the registration form
        } else if (option == 2) {  // Cancel button pressed
            JOptionPane.showMessageDialog(null, "Login canceled.");
        }
    }

	public static void showLoginForm() {
		// TODO Auto-generated method stub
			showLoginForm();  // Show the Login form

	}
}