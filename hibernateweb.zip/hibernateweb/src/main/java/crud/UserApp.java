package crud;
import org.hibernate.cfg.Configuration;
//import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
public class UserApp {
		public static void main(String args[]) {
			Configuration config = new Configuration();
			config.configure("");
			SessionFactory sessionFactory = config.buildSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			User usr = new User();
			usr.setName("Senthil");
			usr.setPassword("CEO");
			usr.setEmail("abc@gmail.com");
			session.persist(usr);
			tx.commit();
	     /*   List < User > usr1= session.createQuery("from emp_master", User.class).list();
	        usr1.forEach(e-> System.out.println(e.getName()));*/
	  		session.close();
		}
		} 
