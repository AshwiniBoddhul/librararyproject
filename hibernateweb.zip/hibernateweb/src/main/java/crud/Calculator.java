package crud;

public class Calculator {
	public int cube(int n){return n*n*n;}  

}
