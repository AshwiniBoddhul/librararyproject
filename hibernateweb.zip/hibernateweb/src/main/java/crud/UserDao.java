package crud;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
public class UserDao { 
	public static int register(User u) {
		int i = 0;
		System.out.println("Hello Register");
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		System.out.println("Step1");
		SessionFactory sessionFactory = config.buildSessionFactory();
		System.out.println("Step2");
		Session session = sessionFactory.openSession();
		System.out.println("Step3");
		System.out.println("Name:"+u.getName());
		System.out.println("Password:"+u.getPassword());
		System.out.println("Email:"+u.getEmail());
		Transaction t = session.beginTransaction();
		System.out.println("Step4");
		i = (Integer) session.save(u);
		session.persist(u);
		t.commit();
		session.close();
		return i;
	}
	
}