package com.studquiz;

import javax.swing.*;
import java.sql.*;

public class Quiz {
    static final String DB_URL = "jdbc:mysql://localhost/quiz";
    static final String USER = "root";
    static final String PASS = "Root@123";
    static final String QUERY = "SELECT id, Question, OptionA, OptionB, OptionC, OptionD FROM qquestion"; // Ensure correct table and column names

    // Function to display a question and get user's answer
    public static void qquestion(String id, String question, String a, String b, String c, String d) {
        String answer = JOptionPane.showInputDialog(id + ". " + question + "\n" + "A: " + a + "\n" + "B: " + b + "\n" + "C: " + c + "\n" + "D: " + d);
        // Here you can add logic to check if the answer is correct
    }

    // Function to show the quiz
    public static void showQuiz() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(QUERY);
            while (rs.next()) {
                qquestion(String.valueOf(rs.getInt("id")), rs.getString("Question"), rs.getString("OptionA"), rs.getString("OptionB"), rs.getString("OptionC"), rs.getString("OptionD"));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}