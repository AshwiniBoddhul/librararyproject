package com.studquiz;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Registration {

    static final String DB_URL = "jdbc:mysql://localhost/quiz";
    static final String USER = "root";
    static final String PASS = "Root@123";

    public static void registration() {
        JTextField emailField = new JTextField(20);
        JTextField fullNameField = new JTextField(20);
        JTextField numberField = new JTextField(20);
        JTextField collegeNameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JPasswordField confirmPasswordField = new JPasswordField(20);

        JPanel panel = new JPanel();
        panel.setLayout(new java.awt.GridLayout(6, 2));
        panel.add(new javax.swing.JLabel("Email:"));
        panel.add(emailField);
        panel.add(new javax.swing.JLabel("Full Name:"));
        panel.add(fullNameField);
        panel.add(new javax.swing.JLabel("Number:"));
        panel.add(numberField);
        panel.add(new javax.swing.JLabel("College Name:"));
        panel.add(collegeNameField);
        panel.add(new javax.swing.JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new javax.swing.JLabel("Confirm Password:"));
        panel.add(confirmPasswordField);
        
    	String[] options = {"OK", "Login", "Cancel"};
        int option = JOptionPane.showOptionDialog(null, panel, "Registration", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[1]);
        if (option == JOptionPane.OK_OPTION)
         if (option == 0 )  // OK or Login button pressed
        	{
            String email = emailField.getText();
            String fullName = fullNameField.getText();
            String number = numberField.getText();
            String collegeName = collegeNameField.getText();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());

            // Basic validation
            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(null, "Passwords do not match!");
                return;
            }

            // Insert into database
            String insertQuery = "INSERT INTO registration (EmailID, FULLName, Number, COLLEGENAME, Password, Conformpassword) VALUES (?, ?, ?, ?, ?, ?)";
            try {
            	Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement pstmt = conn.prepareStatement(insertQuery);
                pstmt.setString(1, email);
                pstmt.setString(2, fullName);
                pstmt.setString(3, number);
                pstmt.setString(4, collegeName);
                pstmt.setString(5, password);
                pstmt.setString(6, confirmPassword);

                int rowsAffected = pstmt.executeUpdate();
           
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Registration successful!");
                } else {
                    JOptionPane.showMessageDialog(null, "Registration failed!");
                }
            }catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Registration failed: " + e.getMessage());
            }
        	}
              /* if(option == 1) 
               { 
              	 Login.showLoginForm();  // Show the registration form
            }*/
            }
	public static void showRegistrationForm() 
	{
        registration();  // Show the registration form
	}
	public static void main(String[] args) {
        showRegistrationForm();
	}
   }
   
 
